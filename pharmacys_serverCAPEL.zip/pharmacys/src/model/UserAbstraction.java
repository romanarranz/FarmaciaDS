package model;

public interface UserAbstraction {
	public boolean sendResetMail();
	public boolean sendVerificationMail();
}
